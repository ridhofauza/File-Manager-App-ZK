package com.learn.simpleapp.services;

public interface MyService {

	String ask(String question);
}
